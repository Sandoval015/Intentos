
public class App {
     public static void main(String[] args) {
         //creacion de objetos para que se pueda acceder a ellos
         Operations modelo =  new Operations();
         Visual vista = new Visual();
         Controlador controlador = new Controlador(modelo, vista);
         controlador.iniciar();
                 // Invoca el metodo mostrar de la clase Menu
    }
}
