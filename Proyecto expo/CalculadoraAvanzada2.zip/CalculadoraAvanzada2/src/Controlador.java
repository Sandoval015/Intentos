// termiar el modelo vista, clase y controlador
public class Controlador {
    
    private Operations modelo ;
    private Visual vista;
    private Menu menu = new Menu();//instancia del ojeto
    
    //aqui lo que hago es darle vista y modelo y los instancio
    //todo esto para que controlador pueda acceder a todo sin crearlos dentro de la clase
    public Controlador(Operations modelo, Visual vista) {
        this.modelo = modelo;//guarda la referencia del objeto Operations
        this.vista = vista;
    }
    //con esto simplemente llamo al menu
    public void iniciar(){
        menu.mostrar();
    }
    
    
}
//esto lo hago para conecte operations y vista, es un agregado para mas orden pero esta incompleto 
//deberia agregar mas cosas para que el sea el maneje las ejecuciones de las operaciones


