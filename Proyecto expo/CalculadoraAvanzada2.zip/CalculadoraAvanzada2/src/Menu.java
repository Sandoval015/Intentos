import javax.swing.JOptionPane;

public class Menu {
    
    public void mostrar() {
        int opcion; // Declarar la variable fuera del bucle  
        do {
         String op = JOptionPane.showInputDialog(" ====================Calculadora Grafica======================\n"
                 + "Seleccione la operacion:\n"
                 + "1) Suma.\n"
                 + "2) Resta.\n"
                 + "3) Multiplicacion.\n"
                 + "4) Salir.");
         
         opcion = Integer.parseInt(op); // Asignar el valor a la variable declarada antes
         
         switch (opcion) {
             case 1 -> Visual.visualsuma();
             case 2 -> Visual.visualresta();
             case 3 -> Visual.visualmultiplicacion();
             case 4 -> Visual.salir();
             default -> Visual.invalido();
            } 
        } while (opcion != 4); // Corregir la condición para que el bucle termine correctamente
    }
}
