                                                                                                       
// Clase que contiene los métodos para hacer operaciones matemáticas
public class Operations {
    //declaracion de  variables 
    private int num1; // Primer número
    private int num2; // Segundo número
    private int result;

    
    //creo el costructor vacio para crear un objeto sin inicializarlo
    public Operations() {
    }
    
    //ahora creo un constructor con dos parametros para las dos variables
    //cuando se crea el objeto Operations sus valores se asignan a las variables
    public Operations(int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
    }
    
    // Métodos para obtener o cambiar los valores de num1 y num2 si es necesario
    // los getters devuelven valores y los setters los modifican 
    public int getNum1() { return num1; }
    public void setNum1(int num1) { this.num1 = num1; }
    public int getNum2() { return num2; }
    public void setNum2(int num2) { this.num2 = num2; }

    // Método que suma los dos números 
    //en todos los casos su resultado se guarda en result
    public void sumar() {
        result = num1 + num2;
    }

    // Método que resta el segundo número al primero
    public void restar() {
     result = num1 - num2;
    }

    // Método que multiplica los dos números
    public void multiplicar() {
        result=  num1 * num2;
    }
    
    //devuelvo el valor almacenado en result
  public int getResult(){
      return result; 
    } 
}
