
import javax.swing.JOptionPane;


public class Visual {  
    public static void visualsuma() {
         String num1 = JOptionPane.showInputDialog("Ingrese el primer número: ");
         int numero1 = Integer.parseInt(num1); 
         String num2 = JOptionPane.showInputDialog("Ingrese el segundo número: "); 
         int numero2 = Integer.parseInt(num2);
         //creo un objeto de la clase operations y le pasamos como argumentos los valores numero1 y numero2 inicializados
         Operations operacion = new Operations(numero1, numero2);//instancia
         operacion.sumar(); //llamo el metodo sumar 
         int rsuma = operacion.getResult(); //el valor que le dio sumar a result se lo doy a la variable rsuma
         JOptionPane.showMessageDialog(null, "El resultado de la suma es: " + rsuma);
    }
    public static void visualresta() {
         String num1 = JOptionPane.showInputDialog("Ingrese el primer número: ");
         int numero1 = Integer.parseInt(num1);  
         String num2 = JOptionPane.showInputDialog("Ingrese el segundo número: "); 
         int numero2 = Integer.parseInt(num2);
         Operations operacion = new Operations(numero1, numero2);
         operacion.restar(); //llamo el metodo sumar 
         int rresta = operacion.getResult();
         JOptionPane.showMessageDialog(null, "El resultado de la resta es: " + rresta);
    }
    public static void visualmultiplicacion() {
         String num1 = JOptionPane.showInputDialog("Ingrese el primer número: ");
         int numero1 = Integer.parseInt(num1);  
         String num2 = JOptionPane.showInputDialog("Ingrese el segundo número: "); 
         int numero2 = Integer.parseInt(num2);
         Operations operacion = new Operations(numero1, numero2);
         operacion.multiplicar(); //llamo el metodo sumar 
         int rmultiplicar = operacion.getResult();
         JOptionPane.showMessageDialog(null, "El resultado de la resta es: " + rmultiplicar);
     }
    public static void invalido() {
      
        JOptionPane.showMessageDialog(null, "La opcion seleccionada es invalida, intente de nuevo");
         
    }
    public static void salir() {
    JOptionPane.showMessageDialog(null, "Gracias por utilizar el programa, vuelva pronto\n\nFIN");
    }
}
